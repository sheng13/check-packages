$ErrorActionPreference = "SilentlyContinue"

$DefaultItems = @(
    "Google Chrome", "Microsoft Edge", "Firefox", "7-Zip",
    "Git", "Visual Studio Code", "Python", "Java",
    "Docker Desktop", "OpenSSH Client", "Hyper-V", "IIS"
)

$Rules = @{
    "git"              = @{ Apps=@("Git"); Commands=@("git"); Features=@() }
    "python"           = @{ Apps=@("Python"); Commands=@("python", "py"); Features=@() }
    "java"             = @{ Apps=@("Java", "JDK"); Commands=@("java"); Features=@() }
    "google chrome"    = @{ Apps=@("Google Chrome"); Commands=@("chrome"); Features=@() }
    "microsoft edge"   = @{ Apps=@("Microsoft Edge"); Commands=@("msedge"); Features=@() }
    "firefox"          = @{ Apps=@("Mozilla Firefox", "Firefox"); Commands=@("firefox"); Features=@() }
    "7-zip"            = @{ Apps=@("7-Zip"); Commands=@("7z"); Features=@() }
    "visual studio code" = @{ Apps=@("Microsoft Visual Studio Code", "Visual Studio Code"); Commands=@("code"); Features=@() }
    "docker desktop"   = @{ Apps=@("Docker Desktop"); Commands=@("docker"); Features=@() }
    "openssh client"   = @{ Apps=@("OpenSSH Client"); Commands=@("ssh"); Features=@("OpenSSH.Client~~~~0.0.1.0") }
    "openssh server"   = @{ Apps=@("OpenSSH Server"); Commands=@("sshd"); Features=@("OpenSSH.Server~~~~0.0.1.0") }
    "hyper-v"          = @{ Apps=@(); Commands=@(); Features=@("Microsoft-Hyper-V-All") }
    "iis"              = @{ Apps=@(); Commands=@("inetmgr"); Features=@("IIS-WebServerRole") }
}

function Get-InstalledApps {
    $paths = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )
    Get-ItemProperty $paths | Where-Object { $_.DisplayName } |
        Select-Object DisplayName, DisplayVersion, Publisher -Unique
}

function Test-WindowsFeature([string[]]$Names) {
    foreach ($name in $Names) {
        $capability = Get-WindowsCapability -Online -Name $name
        if ($capability -and $capability.State -eq "Installed") { return $name }

        $feature = Get-WindowsOptionalFeature -Online -FeatureName $name
        if ($feature -and $feature.State -eq "Enabled") { return $name }
    }
    return $null
}

function Get-Rule([string]$Name) {
    $key = $Name.ToLowerInvariant()
    if ($Rules.ContainsKey($key)) { return $Rules[$key] }
    return @{ Apps=@($Name); Commands=@($Name); Features=@() }
}

Write-Host "请选择检查方式："
Write-Host "  1) 使用预设清单"
Write-Host "  2) 自己输入要检查的软件"
do {
    $mode = Read-Host "请输入 1 或 2 [默认 1]"
    if ([string]::IsNullOrWhiteSpace($mode)) { $mode = "1" }
    if ($mode -notin @("1", "2")) { Write-Host "输入无效，请只输入 1 或 2。" -ForegroundColor Yellow }
} while ($mode -notin @("1", "2"))

if ($mode -eq "2") {
    do {
        $raw = Read-Host "输入软件名称（使用逗号、分号分隔）"
        $items = @($raw -split "[,;]" | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -Unique)
        if ($items.Count -eq 0) { Write-Host "没有输入项目，请重新输入。" -ForegroundColor Yellow }
    } while ($items.Count -eq 0)
} else {
    $items = $DefaultItems
}

$fileName = Read-Host "Excel 文件名称 [默认 windows_package_status.csv]"
if ([string]::IsNullOrWhiteSpace($fileName)) { $fileName = "windows_package_status.csv" }
if (-not $fileName.EndsWith(".csv", [System.StringComparison]::OrdinalIgnoreCase)) { $fileName += ".csv" }
$outputPath = Join-Path $PSScriptRoot $fileName

Write-Host "正在读取已安装软件，请稍候..."
$installedApps = @(Get-InstalledApps)
$results = @()

foreach ($item in $items) {
    $rule = Get-Rule $item
    $app = $installedApps | Where-Object {
        $display = $_.DisplayName
        @($rule.Apps | Where-Object { $display -like "*$_*" }).Count -gt 0
    } | Select-Object -First 1

    $command = $null
    foreach ($cmd in $rule.Commands) {
        if (Get-Command $cmd -ErrorAction SilentlyContinue) { $command = $cmd; break }
    }

    $feature = Test-WindowsFeature $rule.Features
    if ($app) {
        $status = "install"
        $basis = "软件: $($app.DisplayName) $($app.DisplayVersion)"
    } elseif ($command) {
        $status = "install"
        $basis = "命令: $command"
    } elseif ($feature) {
        $status = "install"
        $basis = "Windows 功能: $feature"
    } else {
        $status = "uninstall"
        $basis = "未在注册表、命令或已启用功能中检测到"
    }

    $results += [PSCustomObject]@{
        项目 = $item
        状态 = $status
        判断依据 = $basis
        电脑名称 = $env:COMPUTERNAME
        检查时间 = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    }
    Write-Host ("{0,-24} {1}" -f $item, $status)
}

$results | Export-Csv -Path $outputPath -NoTypeInformation -Encoding UTF8
Write-Host "`n完成，Excel 结果：$outputPath" -ForegroundColor Green
Read-Host "按 Enter 关闭"

