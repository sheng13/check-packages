@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0check_windows_apps.ps1"
if errorlevel 1 (
  echo.
  echo 程序执行失败，请确认 check_windows_apps.ps1 与此文件位于同一目录。
  pause
)

