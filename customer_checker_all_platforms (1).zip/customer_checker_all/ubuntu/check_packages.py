#!/usr/bin/env python3  # 指定使用系统环境中的 python3 解释器执行此脚本[cite: 1]
"""Ubuntu / Debian 套件检查工具。

检查 dpkg 套件与可用命令，结果写入 Excel 可开启的 CSV。
退出码：0=全部可用，1=存在未安装项目，2=输入或系统错误。
"""  # 模块级的文档说明字符串（Docstring），简述程序功能与退出码定义[cite: 1]

from __future__ import annotations  # 导入类型注解延迟求值特性，允许在类型声明中使用尚未定义的类[cite: 1]

import csv  # 导入标准库 csv，用于处理 CSV 文件的读写[cite: 1]
import shutil  # 导入标准库 shutil，用于提供高级文件/命令查找操作（如 shutil.which）[cite: 1]
import subprocess  # 导入标准库 subprocess，用于执行系统底层命令[cite: 1]
import sys  # 导入标准库 sys，用于与 Python 解释器及其环境进行交互[cite: 1]
from pathlib import Path  # 从 pathlib 模块导入 Path 对象，用于跨平台的路径操作[cite: 1]


# 定义默认的检查项目列表，每个元素是一个三元组：(展示名称, [关联 dpkg 套件列表], [关联可执行命令列表])[cite: 1]
DEFAULT_ITEMS = [
    ("openssh-server", ["openssh-server"], ["sshd"]),  # 检查 SSH 服务端[cite: 1]
    ("htop", ["htop"], ["htop"]),  # 检查交互式进程查看器 htop[cite: 1]
    ("curl", ["curl"], ["curl"]),  # 检查网络传输工具 curl[cite: 1]
    ("ca-certificates", ["ca-certificates"], ["update-ca-certificates"]),  # 检查根证书套件[cite: 1]
    ("vi", ["vim-tiny", "vim", "nvi"], ["vi"]),  # 检查 vi 文本编辑器及其替代套件[cite: 1]
    ("nano", ["nano"], ["nano"]),  # 检查 nano 文本编辑器[cite: 1]
    ("nc", ["netcat-openbsd", "netcat-traditional"], ["nc", "netcat"]),  # 检查网络连接工具 netcat[cite: 1]
    ("lshw", ["lshw"], ["lshw"]),  # 检查硬件列表查看工具 lshw[cite: 1]
    ("tmux", ["tmux"], ["tmux"]),  # 检查终端复用器 tmux[cite: 1]
    ("git", ["git"], ["git"]),  # 检查版本控制工具 git[cite: 1]
    ("ntp", ["ntp", "ntpsec", "systemd-timesyncd"],
     ["ntpd", "ntpsec", "systemd-timesyncd", "timedatectl"]),  # 检查网络时间同步相关服务[cite: 1]
    ("sendmail", ["sendmail", "sendmail-bin", "postfix", "exim4"], ["sendmail"]),  # 检查邮件发送代理服务[cite: 1]
    ("timeshift", ["timeshift"], ["timeshift"]),  # 检查系统还原备份工具 timeshift[cite: 1]
    ("net-tools", ["net-tools"], ["ifconfig", "netstat"]),  # 检查传统网络工具包[cite: 1]
    ("vsftpd", ["vsftpd"], ["vsftpd"]),  # 检查 FTP 服务端程序[cite: 1]
    ("ipmitool", ["ipmitool"], ["ipmitool"]),  # 检查 IPMI 带外管理工具[cite: 1]
    ("smartmontools", ["smartmontools"], ["smartctl"]),  # 检查硬盘 SMART 监控工具[cite: 1]
    ("nvme-cli", ["nvme-cli"], ["nvme"]),  # 检查 NVMe 固态硬盘管理工具[cite: 1]
    ("sysstat", ["sysstat"], ["sar", "iostat"]),  # 检查系统性能监控工具包[cite: 1]
    ("iotop", ["iotop", "iotop-c"], ["iotop"]),  # 检查磁盘 I/O 监控工具 iotop[cite: 1]
    ("lsof", ["lsof"], ["lsof"]),  # 检查列出打开文件的工具 lsof[cite: 1]
    ("tcpdump", ["tcpdump"], ["tcpdump"]),  # 检查抓包分析工具 tcpdump[cite: 1]
    ("dnsutils", ["dnsutils", "bind9-dnsutils"], ["dig", "nslookup"]),  # 检查 DNS 查询工具包[cite: 1]
    ("jq", ["jq"], ["jq"]),  # 检查 JSON 命令行处理工具 jq[cite: 1]
    ("nfs-kernel-server", ["nfs-kernel-server"], ["rpc.nfsd"]),  # 检查 NFS 共享服务端[cite: 1]
    ("nfs-common", ["nfs-common"], ["mount.nfs"]),  # 检查 NFS 共享客户端基础包[cite: 1]
    ("samba", ["samba"], ["smbd"]),  # 检查 Samba 文件共享服务端[cite: 1]
    ("smbclient", ["smbclient"], ["smbclient"]),  # 检查 Samba 命令行客户端[cite: 1]
    ("cifs-utils", ["cifs-utils"], ["mount.cifs"]),  # 检查 CIFS/Samba 挂载工具[cite: 1]
    ("aide", ["aide", "aide-common"], ["aide"]),  # 检查入侵检测系统 AIDE[cite: 1]
    ("ClamAV", ["clamav", "clamav-daemon"], ["clamscan"]),  # 检查 ClamAV 杀毒软件[cite: 1]
]


# 定义特殊关键字的字典映射，用于将用户自定义输入的项目名规整为标准检查格式[cite: 1]
SPECIAL_ITEMS = {
    "vi": ("vi", ["vim-tiny", "vim", "nvi"], ["vi"]),  # vi 的映射规则[cite: 1]
    "nc": ("nc", ["netcat-openbsd", "netcat-traditional"], ["nc", "netcat"]),  # nc 的映射规则[cite: 1]
    "netcat": ("nc", ["netcat-openbsd", "netcat-traditional"], ["nc", "netcat"]),  # netcat 的映射规则[cite: 1]
    "ntp": ("ntp", ["ntp", "ntpsec", "systemd-timesyncd"],
            ["ntpd", "ntpsec", "systemd-timesyncd", "timedatectl"]),  # ntp 的映射规则[cite: 1]
    "sendmail": ("sendmail", ["sendmail", "sendmail-bin", "postfix", "exim4"],
                 ["sendmail"]),  # sendmail 的映射规则[cite: 1]
    "dnsutils": ("dnsutils", ["dnsutils", "bind9-dnsutils"], ["dig", "nslookup"]),  # dnsutils 的映射规则[cite: 1]
    "iotop": ("iotop", ["iotop", "iotop-c"], ["iotop"]),  # iotop 的映射规则[cite: 1]
    "clamav": ("ClamAV", ["clamav", "clamav-daemon"], ["clamscan"]),  # clamav 的映射规则[cite: 1]
    "aide": ("aide", ["aide", "aide-common"], ["aide"]),  # aide 的映射规则[cite: 1]
}


# dpkg-query=ubuntu查询工具  -w=指定套件  '-f={Status}'=显示套件状态
def package_installed(name: str) -> bool:  # 定义函数：接收套件名字符串，返回布尔值表示是否安装[cite: 1]
    result = subprocess.run(  # 执行外部子进程命令[cite: 1]
        ["dpkg-query", "-W", "-f=${Status}\n", name],  # 执行 dpkg-query 查询指定套件状态[cite: 1]
        stdout=subprocess.PIPE,  # 将正常输出保存到 result.stdout[cite: 1]
        stderr=subprocess.DEVNULL,  # 隐藏错误信息（重定向到空设备）[cite: 1]
        text=True,  # 将输出转换为字符串形式而非字节流[cite: 1]
        check=False,  # 命令失败时不抛出异常中断 Python[cite: 1]
    )  # 子进程调用结束[cite: 1]
    return result.returncode == 0 and result.stdout.strip() == "install ok installed"  # 返回码为 0 且状态文本为 "install ok installed" 时说明已完整安装[cite: 1]


def make_item(name: str):  # 定义函数：根据输入的名称生成标准格式的三元组项[cite: 1]
    return SPECIAL_ITEMS.get(name.lower(), (name, [name], [name]))  # 如果在特殊字典中匹配到（不区分大小写）则使用预设规则，否则默认名称、套件、命令均相同[cite: 1]


def select_items():  # 定义函数：处理交互式选择检查清单的逻辑[cite: 1]
    print("请选择检查方式：")  # 打印提示信息[cite: 1]
    print(f"  1) 使用预设清单（{len(DEFAULT_ITEMS)} 项）")  # 打印选项 1 及其预设项数量[cite: 1]
    print("  2) 自己输入要检查的项目")  # 打印选项 2[cite: 1]

    while True:  # 开启死循环直到获取有效输入[cite: 1]
        mode = input("请输入 1 或 2 [默认 1]：").strip() or "1"  # 获取用户输入并去除首尾空格，若为空则默认选择 "1"[cite: 1]
        if mode in {"1", "2"}:  # 验证输入合法性[cite: 1]
            break  # 输入合法，跳出循环[cite: 1]
        print("输入无效，请只输入 1 或 2。")  # 输入非法时提示重新输入[cite: 1]

    if mode == "1":  # 如果用户选择了预设模式[cite: 1]
        return DEFAULT_ITEMS  # 直接返回预设的检查项目列表[cite: 1]

    print("请输入套件或命令名称，可用空格、逗号或分号分隔。")  # 提示用户自定义输入的格式[cite: 1]
    print("示例：curl git nginx; docker.io, clamav")  # 打印输入示例[cite: 1]
    while True:  # 开启死循环获取自定义输入[cite: 1]
        raw = input("> ").replace(",", " ").replace(";", " ")  # 读取输入，并将逗号、分号统一替换为空格[cite: 1]
        names = list(dict.fromkeys(raw.split()))  # 切分字符串为列表，并利用 dict.fromkeys 去重同时保持原有顺序[cite: 1]
        if names:  # 若解析后列表不为空[cite: 1]
            return [make_item(name) for name in names]  # 为每个输入的名称生成检查项三元组并返回[cite: 1]
        print("没有输入项目，请重新输入；按 Ctrl+C 可退出。")  # 输入为空时提示用户[cite: 1]


def output_path() -> Path:  # 定义函数：获取导出 CSV 文件的 Path 对象[cite: 1]
    name = input("Excel 文件名称 [默认 package_status.csv]：").strip()  # 提示用户输入文件名，默认 package_status.csv[cite: 1]
    path = Path(name or "package_status.csv").expanduser()  # 转换为 Path 对象，并展开波浪号 `~` 为用户家目录[cite: 1]
    if path.suffix.lower() != ".csv":  # 检查后缀名是否为 .csv[cite: 1]
        path = path.with_name(path.name + ".csv")  # 若不是 .csv 则自动补全该扩展名[cite: 1]
    return path  # 返回最终路径对象[cite: 1]


def main() -> int:  # 定义主程序入口函数，返回整数类型的退出码[cite: 1]
    if shutil.which("dpkg-query") is None:  # 在 PATH 中检测是否存在 dpkg-query 工具[cite: 1]
        print("错误：这个程序仅适用于 Ubuntu、Debian 及其衍生系统。")  # 若不存在则打印错误提示[cite: 1]
        return 2  # 返回状态码 2 表示系统环境不符合要求[cite: 1]

    items = select_items()  # 调用函数获取要检查的项目列表[cite: 1]
    csv_path = output_path()  # 调用函数获取 CSV 保存路径[cite: 1]
    rows = []  # 初始化写入 CSV 的行数据列表[cite: 1]
    missing_packages = []  # 初始化未安装套件的收集列表[cite: 1]

    print(f"{'检查项目':<22} {'结果':<12} 判断依据")  # 格式化打印终端表头[cite: 1]
    print(f"{'-' * 22:<22} {'-' * 12:<12} {'-' * 30}")  # 打印表头下的分割线[cite: 1]

    for label, packages, commands in items:  # 遍历每个检查项目（解包为标签、套件列表、命令列表）[cite: 1]
        installed_package = next((p for p in packages if package_installed(p)), None)  # 找到第一个已安装的 dpkg 套件，没有则为 None[cite: 1]
        installed_command = next((c for c in commands if shutil.which(c)), None)  # 找到第一个可用的系统命令，没有则为 None[cite: 1]
        suggested = packages[0]  # 默认使用套件列表中的第一个作为建议安装套件[cite: 1]

        if installed_package:  # 条件 1：检测到了 dpkg 套件已安装[cite: 1]
            status = "install"  # 状态标记为已安装[cite: 1]
            basis = f"package: {installed_package}"  # 记录判断依据：具体套件名[cite: 1]
            suggestion = ""  # 建议为空[cite: 1]
            display = "已安装"  # 终端展示文本[cite: 1]
        elif installed_command:  # 条件 2：未找到 dpkg 套件但找到了可用的命令[cite: 1]
            status = "install"  # 状态标记为已安装[cite: 1]
            basis = f"command: {installed_command}（可能由替代套件提供）"  # 记录判断依据：命令存在[cite: 1]
            suggestion = ""  # 建议为空[cite: 1]
            display = "可使用"  # 终端展示文本[cite: 1]
        else:  # 条件 3：套件和命令均未找到[cite: 1]
            status = "uninstall"  # 状态标记为未安装[cite: 1]
            basis = "未检测到套件或命令"  # 记录判断依据[cite: 1]
            suggestion = suggested  # 建议安装默认套件[cite: 1]
            display = "未安装"  # 终端展示文本[cite: 1]
            missing_packages.append(suggested)  # 将缺少的套件加入缺失列表中[cite: 1]

        rows.append([label, status, basis, suggestion])  # 追加当前项的详细数据到 CSV 行列表[cite: 1]
        print(f"{label:<22} {display:<12} {basis}")  # 格式化实时打印当前项的检查结果到终端[cite: 1]

    try:  # 捕获文件写入过程中可能的 IO 异常[cite: 1]
        csv_path.parent.mkdir(parents=True, exist_ok=True)  # 自动递归创建导出文件所在父目录[cite: 1]
        with csv_path.open("w", encoding="utf-8-sig", newline="") as file:  # 以 utf-8-sig（含 BOM，方便 Excel 读取防乱码）编码打开文件[cite: 1]
            writer = csv.writer(file)  # 创建 CSV 写入器[cite: 1]
            writer.writerow(["项目", "状态", "判断依据", "建议套件"])  # 写入 CSV 标题行[cite: 1]
            writer.writerows(rows)  # 写入所有检测结果行[cite: 1]
    except OSError as error:  # 捕获操作系统相关的读写错误[cite: 1]
        print(f"错误：无法写入 CSV：{error}")  # 打印错误原因[cite: 1]
        return 2  # 返回状态码 2 表示写入失败[cite: 1]

    installed_count = len(items) - len(missing_packages)  # 计算可用项目的数量[cite: 1]
    print(f"\n统计：可用 {installed_count} 项，缺少 {len(missing_packages)} 项，共 {len(items)} 项。")  # 打印最终统计摘要[cite: 1]
    print(f"Excel 结果已保存到：{csv_path.resolve()}")  # 打印 CSV 文件的绝对路径[cite: 1]

    if missing_packages:  # 如果存在缺失的套件[cite: 1]
        packages_text = " ".join(dict.fromkeys(missing_packages))  # 对缺失套件进行去重，并用空格连接成字符串[cite: 1]
        print("\n安装所有缺少的建议套件：")  # 打印提示[cite: 1]
        print(f"  sudo apt update && sudo apt install {packages_text}")  # 拼接并打印一键安装缺失套件的 apt 命令[cite: 1]
        return 1  # 返回状态码 1 表示存在未安装项[cite: 1]

    print("全部项目均已安装或有可用的替代命令。")  # 若全部就绪，打印完成提示[cite: 1]
    return 0  # 返回状态码 0 表示全部项目均就绪[cite: 1]


if __name__ == "__main__":  # 判断程序是否主入口运行[cite: 1]
    try:  # 捕获退出信号[cite: 1]
        raise SystemExit(main())  # 调用 main 函数，并根据其返回值触发系统退出[cite: 1]
    except KeyboardInterrupt:  # 捕获用户中断按键 Ctrl+C[cite: 1]
        print("\n已取消检查。")  # 打印取消提示[cite: 1]
        raise SystemExit(130)  # 以标准 UNIX 中断信号对应的 130 状态码退出[cite: 1]
