三系统顾客检查工具
==================

请选择顾客设备对应的资料夹：

1. Ubuntu / Debian
   文件：ubuntu/check_packages.py
   执行：python3 check_packages.py
   功能：使用 dpkg-query 与命令路径自动检查套件，输出 CSV。

2. Windows 10 / 11
   文件：windows/run_windows_checker.bat
   使用：双击 BAT 启动。
   功能：读取已安装软件、命令与 Windows 功能，输出 CSV。

3. iPhone / iPad
   文件：ios/ios_device_app_checker.html
   使用：以能执行本地 HTML 的浏览器或 HTML 预览工具打开，或放到受信任的内部网站后用 Safari 打开。
   功能：显示浏览器允许取得的设备信息；手动记录 App 的 install/uninstall 状态并导出 CSV。

重要限制
--------
- 三个系统的检查方法不同，因此不能由同一段程序在所有设备上自动检查。
- iOS 沙盒不允许网页或一般第三方 App 列出全部已安装 App，必须人工确认。
- 所有版本只进行检查和导出，不会自动安装、删除或修改软件。
- 在顾客设备执行前，应先取得顾客授权，并遵守公司的资讯安全政策。

